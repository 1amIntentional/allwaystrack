//
//  Commodity+CoreDataClass.swift
//  Allways
//
//  Created by Jairo Batista on 11/4/16.
//  Copyright © 2016 AllWays. All rights reserved.
//

import Foundation
import CoreData

@objc(Commodity)
public class Commodity: NSManagedObject {

}
