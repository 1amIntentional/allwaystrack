//
//  AllwaysTests.swift
//  AllwaysTests
//
//  Created by Jairo Batista on 9/29/16.
//  Copyright © 2016 AllWays. All rights reserved.
//

import XCTest
@testable import Allways

class AllwaysTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    //// INTERVAL TEST ////
    
    func testIntervalExist() {
        XCTAssertNotNil(IntervalManager.sharedInstance, "Interval singleton does not exist")
    }
    
    func testIntervalSetMethod() {
        // Test that interval set method works properly
    }
    
    func testIntervalIsInt() {
        // Test that interval is Int
    }
    
    func testIntervalIsEqualToSavedInterval() {
        // Test that interval is equivelant to NSUserDefaults saved value
        let instance = IntervalManager.sharedInstance
        let value = 0
        instance.set(interval: value)
        instance.save()
        
        // User Defaults Value
        let recoveredInterval = UserDefaults.standard.value(forKey: "interval") as? Int
        XCTAssertEqual(recoveredInterval, value, "IntervalManager not saving in User Defaults")
    }
    
    
    //// PHONE TEST ////
    
    func testNumberExist() {
        XCTAssertNotNil(PhoneManager.sharedInstance, "Phone number instance does not exist")
    }
    
    func testSetNumberMethod() {
        // Test that method works properly
    }
    
    func testNumberIsEqualToSavedValue() {
        // Test that phonenumber is equal to saved value in User Defaults
        let instance = PhoneManager.sharedInstance
        let value = "9563373109"
        instance.set(number: value)
        instance.save()
        
        // User Defaults
        let recoveredNumber = UserDefaults.standard.value(forKey: "phone") as? String
        XCTAssertEqual(value, recoveredNumber, "PhoneManager not saving number in User Defaults.")
    }
    
    
    //// SERVER ID TEST ////
    
    func testServerIDExist() {
        XCTAssertNotNil(ServerIDManager.sharedInstance, "Server ID does not exist.")
    }
        
    func testServerIDIsEqualToSavedValue() {
        let instance = ServerIDManager.sharedInstance
        let value = "0"
        instance.set(serverID: value)
        instance.save()
        
        // UserDefaults Value
        let recoveredID = UserDefaults.standard.value(forKey: "serverID") as? String
        XCTAssertEqual(value, recoveredID, "ServerID not saving value in User Defaults.")
    }
    
    
    //// LOAD ID TEST ////
    
    func testLoadIDExist() {
        XCTAssertNotNil(LoadIDManager.sharedInstance, "LoadID does not exist.")
    }
    
    func testLoadIDIsEqualToSavedValue() {
        let instance = LoadIDManager.sharedInstance
        let value = "BOOM"
        instance.set(loadID: value)
        instance.save()
        
        // UserDefault
        let recoveredID = UserDefaults.standard.value(forKey: "loadID") as? String
        XCTAssertEqual(value, recoveredID, "LoadID does not save value in User Defaults")
    }
    
    
    //// WORKORDER TEST ////
    
    func testWorkOrderExist() {
        XCTAssertNotNil(WorkOrderManager.sharedInstance, "Work Order does not exist.")
    }
    
    func testWorkOrderIsEqualToSavedValue() {
        let instance = WorkOrderManager.sharedInstance
        let value = "XLED"
        instance.set(wo: value)
        instance.save()
        
        // UserDefault
        let recoveredValue = UserDefaults.standard.value(forKey: "workOrder") as? String
        XCTAssertEqual(recoveredValue, value, "Work order does not save value in User Defaults.")
    }
    
    
    //// ACCOUNT ID TEST ////
    
    func testAccountIDExist() {
        XCTAssertNotNil(AccountIDManager.sharedInstance, "Account ID does not exist.")
    }
    
    func testAccountIDIsEqualToSavedValue() {
        let instance = AccountIDManager.sharedInstance
        let value = "5"
        instance.set(accountID: value)
        instance.save()
        
        // UserDefaults
        let recoveredValue = UserDefaults.standard.value(forKey: "accountID") as? String
        XCTAssertEqual(value, recoveredValue, "Account ID is not saving in User Defaults.")
    }
}




