//
//  FirstVCTests.swift
//  Allways
//
//  Created by Jairo Batista on 10/21/16.
//  Copyright © 2016 AllWays. All rights reserved.
//

import XCTest
@testable import Allways

class StopsVCTests: XCTestCase {
    var vc: StopsVC!
    
    override func setUp() {
        super.setUp()
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        vc = storyboard.instantiateViewController(withIdentifier: "StopsVC") as! StopsVC
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
}
