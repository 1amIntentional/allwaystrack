//
//  ClassTests.swift
//  Allways
//
//  Created by Jairo Batista on 10/18/16.
//  Copyright © 2016 AllWays. All rights reserved.
//

import XCTest
@testable import Allways

class ClassTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    
    //// APICall Tests ////
    
    func testAPICallSetPhoneNumber() {
        let value = "7896751212"
        let data = APICall(phone: value)
        XCTAssertEqual(data.phone(), value, "APICall not setting phone number.")
    }
    
    func testAPICallInstance() {
        XCTAssertNotNil(APICall(phone: "9898899443"), "APICall does not exist")
    }
    
    func testAPICallJSON() {
        let _ = APICall(phone: "9563373109")
        // Test that API Call goes through
    }
    
    
    //// LocationAPICall Tests ////
    
    func testLocationAPICallExist() {
        let instance = LocationAPICall(phone: "956", lat: 16.16, lng: 151, head: 654156, speed: 15, street: "ya", city: "laredo", zip: "0700", state: "TX", country: "USA", accountID: "3214", serverID: "8549", loadID: "SLDF")
        XCTAssertNotNil(instance, "LocationAPICall does not exist.")
    }
}
