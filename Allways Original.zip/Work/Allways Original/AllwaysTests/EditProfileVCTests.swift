//
//  EditProfileVCTests.swift
//  Allways
//
//  Created by Jairo Batista on 11/1/16.
//  Copyright © 2016 AllWays. All rights reserved.
//

import XCTest
import UIKit
@testable import Allways

class EditProfileVCTests: XCTestCase {
    var vc: EditProfileVC!
    
    override func setUp() {
        super.setUp()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        vc = storyboard.instantiateViewController(withIdentifier: "EditProfileVC") as! EditProfileVC
        let _ = vc.view
    }

    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testPhoneTextFieldExist() {
        XCTAssertNotNil(vc.phoneNumberTextField, "Phone number text field does not exist.")
    }
    
}
