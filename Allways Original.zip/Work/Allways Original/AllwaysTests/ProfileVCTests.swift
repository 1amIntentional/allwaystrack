//
//  SecondVCTests.swift
//  Allways
//
//  Created by Jairo Batista on 10/25/16.
//  Copyright © 2016 AllWays. All rights reserved.
//

import XCTest
import UIKit
@testable import Allways

class ProfileVCTests: XCTestCase {
    var vc: ProfileVC!
    
    override func setUp() {
        super.setUp()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        vc = storyboard.instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        let _ = vc.view
        vc.viewDidAppear(true)
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testPhoneNumberButtonExists() {
        XCTAssertNotNil(vc.numberButton)
    }
    
    func testPhoneNumberDisplay() {
        let phone = PhoneManager.sharedInstance
        let label = vc.numberButton.titleLabel?.text
        XCTAssertEqual(label, phone.get(), "Not displaying phone number.")
    }
}
